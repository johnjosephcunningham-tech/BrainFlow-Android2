$ErrorActionPreference = 'Stop'
$port = 8769
$baseUrl = "http://127.0.0.1:$port/"
$url = "http://127.0.0.1:$port/index.html?v=0.3.1"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$log = Join-Path $root 'BrainFlow-Desktop-Launcher.log'

function Log([string]$message) {
    $stamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    Add-Content -LiteralPath $log -Value "[$stamp] $message"
}

function Test-BrainFlowServer {
    try {
        $response = Invoke-WebRequest -UseBasicParsing -Uri $baseUrl -TimeoutSec 1
        return ($response.StatusCode -ge 200 -and $response.StatusCode -lt 500)
    } catch { return $false }
}

function Find-Python {
    foreach ($name in @('py.exe','python.exe','python3.exe')) {
        $cmd = Get-Command $name -ErrorAction SilentlyContinue
        if ($cmd -and $cmd.Source) { return @{ Name=$name; Path=$cmd.Source } }
    }
    return $null
}

try {
    Log 'Launcher v0.3.1 started.'
    Write-Host 'Checking local BrainFlow server...'

    if (-not (Test-BrainFlowServer)) {
        $python = Find-Python
        if (-not $python) {
            throw 'Python was not found. Install Python or make sure py.exe/python.exe is available.'
        }

        # WorkingDirectory already selects the BrainFlow folder. Avoid passing the
        # folder path through Python arguments, which can break on Windows paths.
        if ($python.Name -eq 'py.exe') {
            $serverArgs = @('-3','-m','http.server',"$port",'--bind','127.0.0.1')
        } else {
            $serverArgs = @('-m','http.server',"$port",'--bind','127.0.0.1')
        }

        Log "Starting server with $($python.Name) at $($python.Path), root=$root."
        Write-Host "Starting private server on port $port..."
        Start-Process -FilePath $python.Path -ArgumentList $serverArgs -WorkingDirectory $root -WindowStyle Hidden | Out-Null

        $ready = $false
        for ($i=0; $i -lt 30; $i++) {
            Start-Sleep -Milliseconds 250
            if (Test-BrainFlowServer) { $ready=$true; break }
        }
        if (-not $ready) {
            throw "Local server did not start on port $port. See $log"
        }
    }

    Write-Host 'Server ready. Opening BrainFlow...' -ForegroundColor Green
    Log "Server healthy. Opening $url"

    # cmd /c start delegates URL handling to Windows without requiring a
    # hard-coded browser executable.
    Start-Process -FilePath "$env:ComSpec" -ArgumentList @('/c','start','""',"`"$url`"") -WindowStyle Hidden | Out-Null

    Write-Host 'BrainFlow Desktop is running.' -ForegroundColor Green
    Write-Host "Open: $url"
    Log 'BrainFlow opened successfully.'
    Start-Sleep -Seconds 2
    exit 0
} catch {
    Log "ERROR: $($_.Exception.Message)"
    Write-Host ''
    Write-Host 'BrainFlow Desktop could not start:' -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ''
    Write-Host "Diagnostic log: $log"
    exit 1
}
