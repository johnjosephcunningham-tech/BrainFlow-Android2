-- BrainFlow v3.7.0 Two-Way Sync Beta
-- Apply only inside the BrainFlow Supabase project after reviewing it.
-- This schema supports the protected v3.7.0 phone ↔ desktop sync beta.

create extension if not exists pgcrypto;

create table if not exists public.brainflow_devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  device_id text not null,
  platform text not null default 'unknown',
  app_version text not null default '',
  last_seen_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  unique(user_id, device_id)
);

create table if not exists public.brainflow_spaces (
  id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  local_id text,
  payload jsonb not null default '{}'::jsonb,
  revision bigint not null default 1,
  origin_device_id text,
  last_device_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique(user_id, id),
  unique(user_id, local_id)
);

create table if not exists public.brainflow_projects (
  id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  local_id text,
  space_id uuid,
  payload jsonb not null default '{}'::jsonb,
  revision bigint not null default 1,
  origin_device_id text,
  last_device_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique(user_id, id),
  unique(user_id, local_id),
  foreign key (user_id, space_id) references public.brainflow_spaces(user_id, id)
);

create table if not exists public.brainflow_items (
  id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  local_id text,
  space_id uuid,
  project_id uuid,
  item_type text not null default 'TASK',
  payload jsonb not null default '{}'::jsonb,
  revision bigint not null default 1,
  origin_device_id text,
  last_device_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique(user_id, id),
  unique(user_id, local_id),
  foreign key (user_id, space_id) references public.brainflow_spaces(user_id, id),
  foreign key (user_id, project_id) references public.brainflow_projects(user_id, id)
);

create table if not exists public.brainflow_links (
  id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  local_id text,
  a_item_id uuid,
  b_item_id uuid,
  relation_type text not null default 'RELATED_TO',
  payload jsonb not null default '{}'::jsonb,
  revision bigint not null default 1,
  origin_device_id text,
  last_device_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique(user_id, id),
  unique(user_id, local_id),
  foreign key (user_id, a_item_id) references public.brainflow_items(user_id, id),
  foreign key (user_id, b_item_id) references public.brainflow_items(user_id, id)
);

create table if not exists public.brainflow_sync_events (
  seq bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  entity_table text not null,
  entity_id uuid not null,
  revision bigint not null,
  operation text not null check (operation in ('UPSERT','DELETE')),
  device_id text,
  created_at timestamptz not null default now()
);

alter table public.brainflow_devices enable row level security;
alter table public.brainflow_spaces enable row level security;
alter table public.brainflow_projects enable row level security;
alter table public.brainflow_items enable row level security;
alter table public.brainflow_links enable row level security;
alter table public.brainflow_sync_events enable row level security;

drop policy if exists "devices own rows" on public.brainflow_devices;
create policy "devices own rows" on public.brainflow_devices for all using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "spaces own rows" on public.brainflow_spaces;
create policy "spaces own rows" on public.brainflow_spaces for all using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "projects own rows" on public.brainflow_projects;
create policy "projects own rows" on public.brainflow_projects for all using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "items own rows" on public.brainflow_items;
create policy "items own rows" on public.brainflow_items for all using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "links own rows" on public.brainflow_links;
create policy "links own rows" on public.brainflow_links for all using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "sync events own rows" on public.brainflow_sync_events;
create policy "sync events own rows" on public.brainflow_sync_events for all using (user_id = auth.uid()) with check (user_id = auth.uid());

create index if not exists brainflow_spaces_user_updated_idx on public.brainflow_spaces(user_id, updated_at);
create index if not exists brainflow_projects_user_updated_idx on public.brainflow_projects(user_id, updated_at);
create index if not exists brainflow_items_user_updated_idx on public.brainflow_items(user_id, updated_at);
create index if not exists brainflow_links_user_updated_idx on public.brainflow_links(user_id, updated_at);
create index if not exists brainflow_sync_events_user_seq_idx on public.brainflow_sync_events(user_id, seq);
