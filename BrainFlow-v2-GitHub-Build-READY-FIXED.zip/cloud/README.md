# BrainFlow Cloud Foundation — v3.6.0

This source includes the first cloud/account foundation, but remote synchronization remains disabled by design.

## Implemented in this build

- Existing `brainflow-v3-live` remains the active local storage key.
- A one-time pre-cloud local snapshot is preserved under `brainflow-v3-precloud-backup` before the v3.5-or-earlier state is normalized for cloud readiness.
- Spaces, Projects, Items and Links receive additive sync metadata with a stable UUID, per-entity revision, timestamps, dirty state and device metadata.
- Hard-removing a syncable Item or Link records a tombstone so a future second device cannot silently resurrect it.
- Android can receive a Supabase URL and public anon key from build-time environment variables. No service-role key belongs in the client.
- The existing native Google identity flow is surfaced in Settings, but it is not yet exchanged for a Supabase session.
- `supabase_schema.sql` provides the first relational/RLS schema for review and application to a BrainFlow Supabase project.

## Build-time configuration

Optional public client values:

- `BRAINFLOW_SUPABASE_URL`
- `BRAINFLOW_SUPABASE_ANON_KEY`

If omitted, BrainFlow builds and operates fully locally. Cloud status displays as not configured.

## Not implemented yet

- No remote BrainFlow data reads or writes.
- No Supabase session/token exchange.
- No initial upload/merge.
- No two-way sync cursor processing.
- No conflict resolution UI.
- No Knowledge Source file sync.

This is intentional. The next safe step is to create/configure the Supabase project, apply/review the RLS schema, configure Google as an auth provider if desired, then implement an explicit backup-first initial migration.
