# BrainFlow v3.7.0 — Two-Way Sync Beta

BrainFlow remains local-first. The phone and desktop keep their own `brainflow-v3-live` copy and can synchronize Spaces, Projects, Items, and Relationships through Supabase.

## Implemented in v3.7.0

- Supabase email/password account sign-up and sign-in using the public client key.
- Per-device cloud configuration. No service-role key is supported or required.
- Initial pre-cloud safety backup before the first successful sync.
- Two-way sync for Spaces, Projects, Items, and Relationships.
- Stable cloud UUIDs, per-entity revisions, dirty flags, last-synced revisions, and deletion tombstones.
- Optimistic concurrency checks so a remote edit cannot be silently overwritten after another device changes the same revision.
- Conflict preservation: both the local entity and the remote row are saved under `state.sync.conflicts`; the conflicting local record is not overwritten.
- Same-record detection for first migration so a desktop imported from the phone backup does not create false conflicts.
- RLS ownership rules: every cloud table is restricted to `user_id = auth.uid()`.

## Deliberately not implemented yet

- Automatic background sync. v3.7.0 uses an explicit **SYNC NOW** action while we validate the first real account and migration.
- Conflict-resolution UI. Conflicts are preserved safely but not yet editable through a dedicated merge screen.
- Knowledge Source file sync.
- History/inbox/source metadata sync.
- Realtime subscriptions.

## Setup

1. Create a Supabase project.
2. Open SQL Editor and run `supabase_schema.sql`.
3. In BrainFlow Settings, enter the project URL and the public/publishable (anon) client key. Never enter a service-role key.
4. Create/sign into the same BrainFlow cloud account on phone and desktop.
5. On the device that has the authoritative local data, press **SYNC NOW** first.
6. Then sign in on the second device and press **SYNC NOW**.

The first successful sync preserves the local pre-cloud backup before enabling cloud state.
