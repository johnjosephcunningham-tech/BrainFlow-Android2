# BrainFlow 3.1 — Unified Execution Engine

BrainFlow 3.1 keeps the existing Android identity and `brainflow-v3-live` storage key, but replaces view-by-view task selection with one shared execution projection.

## Source of truth
- Items remain independent records.
- Recurrence remains one master record plus virtual occurrences.
- Calendar, Now, Work, Spaces, Search, widgets and Pressure/Fit all project from the same records.
- Entering a Space only filters scope; it does not change item meaning or ranking rules.

## Execution projection
Every actionable item is projected into one record with:
- effective/active occurrence date
- Pressure
- Fit
- Priority
- bucket: OVERDUE, TODAY, UPCOMING, LATER, ANYTIME or WAITING

## Now
Now is deliberately exclusive to prevent duplicate cards:
1. Brain's Pick
2. Needs Attention
3. Today
4. Coming Up (next 7 days)
5. Ready Anytime (unscheduled actionable work, including Orders)

An item already in Needs Attention is not repeated in Today or Coming Up.

## Work
Work uses the same execution records and filters them into:
ALL / TODAY / UPCOMING / ORDERS / WAITING / RECURRING.

## Search
Search indexes title, First Move, notes, type, aliases, custom tags, Space, Project, priority, status, recurrence, Pressure, Fit and connected-item titles. Order aliases include ORDER, ORDERS, PURCHASE, PURCHASING and REPLENISHMENT.

## Data safety
- applicationId stays `com.brainflow.dem`
- package/MainActivity stay `com.brainflow.app`
- storage key stays `brainflow-v3-live`
- migrations are additive/non-destructive


## v3.1.1 Today workload semantics
The Now header's TODAY counter represents all actionable work on the user's plate today: overdue work carried forward plus work naturally due today. The card sections remain mutually exclusive, so overdue cards stay in Needs Attention and are not duplicated in Scheduled Today.
