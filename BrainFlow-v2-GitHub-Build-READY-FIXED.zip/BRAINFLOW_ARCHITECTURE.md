# BrainFlow 3.1 — Unified Execution Engine

BrainFlow 3.1 keeps the existing Android identity and `brainflow-v3-live` storage key, but replaces view-by-view task selection with one shared execution projection.

## Source of truth
- Items remain independent records.
- Recurrence remains one master record plus virtual occurrences.
- Calendar, Now, Work, Spaces, Search, widgets and Pressure/Fit all project from the same records.
- Entering a Space only filters scope; it does not change item meaning or ranking rules.

## Execution projection
Every actionable item is projected into one record with:
- effective/active occurrence date
- Pressure
- Fit
- Priority
- bucket: OVERDUE, TODAY, UPCOMING, LATER, ANYTIME or WAITING

## Now
Now is deliberately exclusive to prevent duplicate cards:
1. Brain's Pick
2. Needs Attention
3. Today
4. Coming Up (next 7 days)
5. Ready Anytime (unscheduled actionable work, including Orders)

An item already in Needs Attention is not repeated in Today or Coming Up.

## Work
Work uses the same execution records and filters them into:
ALL / TODAY / UPCOMING / ORDERS / WAITING / RECURRING.

## Search
Search indexes title, First Move, notes, type, aliases, custom tags, Space, Project, priority, status, recurrence, Pressure, Fit and connected-item titles. Order aliases include ORDER, ORDERS, PURCHASE, PURCHASING and REPLENISHMENT.

## Data safety
- applicationId stays `com.brainflow.dem`
- package/MainActivity stay `com.brainflow.app`
- storage key stays `brainflow-v3-live`
- migrations are additive/non-destructive


## v3.1.1 Today workload semantics
The Now header's TODAY counter represents all actionable work on the user's plate today: overdue work carried forward plus work naturally due today. The card sections remain mutually exclusive, so overdue cards stay in Needs Attention and are not duplicated in Scheduled Today.


## BrainFlow 3.2 — Order Workflow

ORDER is a first-class execution workflow, not a generic task.

Lifecycle:
1. TO ORDER — driven by Order By.
2. AWAITING CONFIRMATION / PROOF — starts automatically when the order is marked placed. BrainFlow expects the confirmation/proof by the next business morning.
3. PROOF NEEDS APPROVAL — only when a proof is received.
4. CONFIRMED · AWAITING DELIVERY — driven by Receive By.
5. RECEIVED — completes the Order.

Order fields:
- Order By
- Receive By
- Ordered timestamp
- Confirmation/proof expected date
- Confirmation kind/status
- Confirmation/proof received timestamp
- Proof approval timestamp
- Received timestamp

Pressure follows the active stage instead of a single generic due date.

## BrainFlow 3.3 additions
- CLAIM is a first-class actionable work type with customer, DC, PO, BOL, claim number, amount, multi-select claim reasons, responsible party, follow-up date, active workflow, and final Approved / Partially Approved / Not Approved resolution.
- Claims stay active through investigation, submission, waiting, and follow-up. Only a final resolution completes them.
- Every Space now has Environment Knowledge inputs. Android can preserve original PDF, text/CSV, Word, Excel, JSON and image source files in app-private storage. Text/CSV/Word/Excel receive local text indexing where supported; PDF/image originals are stored for future deeper document intelligence.

## v3.4 Manager Workflow checkpoint
- v3.3.0 remains the stable Claims + Knowledge Sources checkpoint.
- IDEA is a first-class non-commitment type: no Pressure, overdue, Now execution, or Brain's Pick until promoted.
- Ideas can be promoted into Tasks while preserving the record, notes, Space, tags, and relationships.
- Task planning adds estimated duration and checklists/subtasks; scheduled date/time acts as the task's calendar time block while Due Date remains the deadline.
- Projects remain optional containers for genuine multi-item initiatives. Normal capture no longer asks One-off vs Project; relationships remain independent.
- Projects can be created inline from the work form after choosing a Space.
- Unassigned is a visible cleanup area; unassigned items still exist in Everything and Search.


## v3.5.0 — Sync Foundation checkpoint

- v3.4.0 remains the rollback checkpoint.
- Existing `brainflow-v3-live` local data is preserved; no destructive migration or storage-key reset.
- State now carries sync metadata: stable device ID, schema version, local revision, last-change timestamp, backup revision/time, and future cloud-sync fields.
- Local mutations increment a state revision, giving future multi-device sync a deterministic change marker.
- Export Backup now emits a versioned BrainFlow backup envelope containing app version, architecture, device ID, revision, export timestamp, and the complete local state.
- Cloud synchronization is intentionally OFF in this checkpoint. No credentials, remote writes, account assumptions, or destructive merges are introduced.
- Next milestone: account/auth + per-entity cloud schema/RLS + one-time safe local migration/merge, then desktop client.

## BrainFlow 3.6.0 — Cloud Account Foundation

- v3.5.0 remains the protected Sync Foundation rollback checkpoint.
- `brainflow-v3-live` remains the active local source of truth; opening v3.6 does not replace local data with cloud state.
- Before older local state is normalized for cloud readiness, BrainFlow preserves a one-time local pre-cloud snapshot under `brainflow-v3-precloud-backup`.
- Spaces, Projects, Items and Links now receive additive per-entity sync metadata: stable UUID (`syncId`), entity revision, created/updated/deleted timestamps, dirty state, and origin/last device IDs.
- Permanent removal of syncable Items/Links records a tombstone for future multi-device deletion propagation.
- Android has safe build-time Supabase public-client configuration hooks. No service-role secret is embedded.
- Existing native Google sign-in is now visible as an account/identity foundation. It remains device-local until a Supabase project/provider is configured and token exchange is implemented.
- A first PostgreSQL/Supabase schema with account ownership and RLS is included under `cloud/supabase_schema.sql`.
- Remote sync remains OFF. There are no remote reads, writes, destructive merges, or empty-cloud replacement paths in v3.6.0.
