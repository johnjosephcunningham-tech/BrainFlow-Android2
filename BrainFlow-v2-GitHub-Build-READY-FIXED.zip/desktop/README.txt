BrainFlow Desktop v0.2.0 — Sync Beta

1. Double-click Start BrainFlow Desktop.bat.
2. Open Settings.
3. Under Phone ↔ Desktop Cloud Sync, enter the same Supabase Project URL and public/publishable key used by the phone.
4. Sign into the same BrainFlow cloud account.
5. Use SYNC NOW.

IMPORTANT
- Do not use a Supabase service-role key.
- The desktop still keeps its own local brainflow-v3-live copy for offline use.
- Automatic background sync is intentionally not enabled in this beta.
- If you previously imported a phone backup, keep it; the sync engine recognizes identical cloud records and avoids false conflicts.
