BrainFlow Desktop v0.4.0 - Work Channels + Actionability

WHAT IS NEW
- Automatic protected two-way sync after startup when signed in.
- Automatic sync shortly after core BrainFlow records change.
- Periodic background sync while BrainFlow remains open.
- Sync when the desktop returns online or becomes active again.
- Header status shows Synced, Syncing, Offline, Conflict, or Changes pending.
- Manual SYNC NOW remains available as a fallback.
- Existing revision, optimistic-concurrency, tombstone, pre-cloud backup, and conflict protections remain in place.

WINDOWS START
1. Extract this ZIP to a new folder.
2. Double-click Start BrainFlow Desktop.bat.
3. This build uses http://127.0.0.1:8770/ to avoid older BrainFlow local servers.

SYNC SAFETY
- BrainFlow uses the existing brainflow-v3-live local data key.
- Supabase credentials/session stay in this browser origin. Because this build uses a new localhost port, you may need to enter the Supabase URL/key and sign in once on this build.
- Only core cloud entities currently sync: Spaces, Projects, Items, and Links. Knowledge files and some local-only support data remain local for now.
- Conflicting records are preserved instead of silently overwritten.

What changed in v0.4.0:
- Work opens to Tasks instead of one mixed list.
- Dedicated channels: Tasks, Orders, Claims, Follow-ups, Waiting On.
- Orders and Claims show workflow lanes.
- Brain's Pick only selects work that is actionable now.
- Daily recurring tasks remain eligible for Brain's Pick.
- Automatic two-way sync remains enabled.
