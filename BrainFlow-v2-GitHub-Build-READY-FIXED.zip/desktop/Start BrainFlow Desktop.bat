@echo off
setlocal
cd /d "%~dp0"

echo Starting BrainFlow Desktop...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-BrainFlow.ps1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo BrainFlow could not start. See BrainFlow-Desktop-Launcher.log in this folder.
  pause
)
exit /b %RC%
