@echo off
setlocal
set "APP=%~dp0index.html"
where msedge.exe >nul 2>nul
if %errorlevel%==0 (
  start "BrainFlow" msedge.exe --app="file:///%APP:\=/%" --start-maximized
  exit /b 0
)
where chrome.exe >nul 2>nul
if %errorlevel%==0 (
  start "BrainFlow" chrome.exe --app="file:///%APP:\=/%" --start-maximized
  exit /b 0
)
start "BrainFlow" "%APP%"
