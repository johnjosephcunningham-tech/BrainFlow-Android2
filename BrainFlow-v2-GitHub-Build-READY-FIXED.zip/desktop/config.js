// BrainFlow Desktop cloud configuration.
// Leave blank until Supabase is configured. Never place a service-role key here.
window.BRAINFLOW_CLOUD_CONFIG = {
  url: "",
  anonKey: "",
  configured: false,
  remoteSyncEnabled: false
};
