package com.brainflow.app;
public class QuickWidget extends BrainFlowWidgetProvider {}
