package com.brainflow.app;

import android.content.*;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

public class IcsProvider extends ContentProvider {
    @Override public boolean onCreate(){return true;}
    private File fileFor(Uri uri) throws FileNotFoundException {
        String name=uri.getLastPathSegment();
        if(name==null || name.contains("/") || name.contains("..")) throw new FileNotFoundException();
        File f=new File(new File(getContext().getCacheDir(),"ics"),name);
        if(!f.exists()) throw new FileNotFoundException();
        return f;
    }
    @Override public String getType(Uri uri){return "text/calendar";}
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException {return ParcelFileDescriptor.open(fileFor(uri),ParcelFileDescriptor.MODE_READ_ONLY);}
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] selectionArgs,String sortOrder){
        try{File f=fileFor(uri);MatrixCursor c=new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE});c.addRow(new Object[]{f.getName(),f.length()});return c;}catch(Exception e){return null;}
    }
    @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException();}
    @Override public int delete(Uri uri,String selection,String[] selectionArgs){return 0;}
    @Override public int update(Uri uri,ContentValues values,String selection,String[] selectionArgs){return 0;}
}
