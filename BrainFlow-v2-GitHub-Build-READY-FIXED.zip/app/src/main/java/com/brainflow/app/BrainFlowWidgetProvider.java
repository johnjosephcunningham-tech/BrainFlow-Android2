package com.brainflow.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

public class BrainFlowWidgetProvider extends AppWidgetProvider {
    public static final String PREFS="brainflow_widgets";
    public static void updateAll(Context c){
        AppWidgetManager m=AppWidgetManager.getInstance(c);
        Class<?>[] cs={BrainWidget.class,DumpWidget.class,FocusWidget.class,TodayWidget.class,WaitingWidget.class,QuickWidget.class};
        for(Class<?> k:cs){android.content.ComponentName n=new android.content.ComponentName(c,k);int[] ids=m.getAppWidgetIds(n);for(int id:ids)update(c,m,id,k);}
    }
    static PendingIntent open(Context c,String target,int code){Intent i=new Intent(c,MainActivity.class);i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);i.putExtra("brainflow_target",target);return PendingIntent.getActivity(c,code,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    static String join(JSONObject j,String key,String empty){JSONArray a=j.optJSONArray(key);if(a==null||a.length()==0)return empty;StringBuilder b=new StringBuilder();for(int i=0;i<Math.min(4,a.length());i++){if(i>0)b.append("\n");b.append("• ").append(a.optString(i));}return b.toString();}
    static void update(Context c,AppWidgetManager m,int id,Class<?> type){
        try{String raw=c.getSharedPreferences(PREFS,0).getString("snapshot","{}");JSONObject j=new JSONObject(raw);RemoteViews v;
            if(type==BrainWidget.class){v=new RemoteViews(c.getPackageName(),R.layout.widget_brain);v.setTextViewText(R.id.w_title,j.optString("brainTitle","Open BrainFlow"));v.setTextViewText(R.id.w_meta,j.optString("brainMeta","What matters now"));v.setOnClickPendingIntent(R.id.w_root,open(c,"now",101));v.setOnClickPendingIntent(R.id.w_action,open(c,"now",102));}
            else if(type==DumpWidget.class){v=new RemoteViews(c.getPackageName(),R.layout.widget_dump);v.setOnClickPendingIntent(R.id.w_root,open(c,"dump",201));}
            else if(type==FocusWidget.class){v=new RemoteViews(c.getPackageName(),R.layout.widget_list);v.setTextViewText(R.id.w_heading,"FOCUS SESSION");v.setTextViewText(R.id.w_subheading,j.optString("focusMeta","Tap to choose what to focus on"));v.setTextViewText(R.id.w_list,j.optString("focusTitle","").isEmpty()?"No focus session running":j.optString("focusTitle"));v.setOnClickPendingIntent(R.id.w_root,open(c,"now",301));}
            else if(type==TodayWidget.class){v=new RemoteViews(c.getPackageName(),R.layout.widget_list);v.setTextViewText(R.id.w_heading,"TODAY · "+j.optInt("todayCount",0));v.setTextViewText(R.id.w_subheading,j.optString("todayMeta","Your day at a glance"));v.setTextViewText(R.id.w_list,join(j,"today","Nothing scheduled or due today"));v.setOnClickPendingIntent(R.id.w_root,open(c,"now",401));}
            else if(type==WaitingWidget.class){v=new RemoteViews(c.getPackageName(),R.layout.widget_list);v.setTextViewText(R.id.w_heading,"WAITING ON · "+j.optInt("waitingCount",0));v.setTextViewText(R.id.w_subheading,j.optString("waitingMeta","Open loops BrainFlow is remembering"));v.setTextViewText(R.id.w_list,join(j,"waiting","Nothing waiting on someone"));v.setOnClickPendingIntent(R.id.w_root,open(c,"waiting",501));}
            else {v=new RemoteViews(c.getPackageName(),R.layout.widget_quick);v.setOnClickPendingIntent(R.id.w_task,open(c,"task",601));v.setOnClickPendingIntent(R.id.w_event,open(c,"event",602));v.setOnClickPendingIntent(R.id.w_dump,open(c,"dump",603));v.setOnClickPendingIntent(R.id.w_focus,open(c,"now",604));}
            m.updateAppWidget(id,v);
        }catch(Exception ignored){}
    }
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)update(c,m,id,getClass());}
}
