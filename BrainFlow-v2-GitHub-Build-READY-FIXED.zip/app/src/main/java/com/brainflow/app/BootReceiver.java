package com.brainflow.app;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){
        if(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())){
            android.content.SharedPreferences p=c.getSharedPreferences(NotificationReceiver.PREF,0);
            NotificationReceiver.ensureChannels(c);
            NotificationReceiver.setDaily(c,p.getBoolean("daily",false),p.getInt("hour",8),p.getInt("minute",0));
            NotificationReceiver.setMorningSummary(c,p.getBoolean("morning",false));
            NotificationReceiver.reschedulePersistedEvents(c);
        }
    }
}
