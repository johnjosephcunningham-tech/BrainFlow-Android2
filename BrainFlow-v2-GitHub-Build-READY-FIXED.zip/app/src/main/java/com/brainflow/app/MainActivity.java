package com.brainflow.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.provider.CalendarContract;
import org.json.JSONObject;
import android.os.*;
import android.webkit.*;
import android.view.View;

public class MainActivity extends Activity {
    static final String HOST="appassets.androidplatform.net";
    static final int NOTIFICATION_PERMISSION_REQUEST=2001;
    WebView webView;
    String pendingTarget="now";
    String pendingSharedText=null;
    boolean pendingTestNotification=false;
    String pendingTestTitle="BrainFlow test";
    String pendingTestBody="Notifications are working.";
    String pendingTestTarget="now";

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        if(Build.VERSION.SDK_INT>=21){
            getWindow().setStatusBarColor(Color.parseColor("#07101f"));
            getWindow().setNavigationBarColor(Color.parseColor("#f3f5ff"));
            if(Build.VERSION.SDK_INT>=23){
                getWindow().getDecorView().setSystemUiVisibility(getWindow().getDecorView().getSystemUiVisibility() & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            }
        }
        NotificationReceiver.ensureChannels(this);
        pendingTarget=getIntent().getStringExtra("brainflow_target");
        if(pendingTarget==null) pendingTarget="now";
        captureIncoming(getIntent());
        webView=new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#f3f5ff"));
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setLoadsImagesAutomatically(true);
        if(Build.VERSION.SDK_INT>=21) s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new NativeBridge(),"BrainFlowNative");
        webView.setWebChromeClient(new WebChromeClient()); webView.setWebViewClient(new Client());
        setContentView(webView); webView.loadUrl("https://"+HOST+"/index.html");
    }
    class Client extends WebViewClient {
        @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){
            if(!HOST.equals(r.getUrl().getHost())) return null;
            String p=r.getUrl().getPath(); if(p==null||p.equals("/")||p.isEmpty())p="/index.html";
            try{String rel=p.startsWith("/")?p.substring(1):p; return new WebResourceResponse(mime(rel),"utf-8",getAssets().open(rel));}
            catch(Exception e){return null;}
        }
        @Override public void onPageFinished(WebView v,String url){super.onPageFinished(v,url);deliverTarget();}
    }
    void captureIncoming(Intent i){
        if(i==null)return;
        if(Intent.ACTION_SEND.equals(i.getAction()) && i.getType()!=null && i.getType().startsWith("text/")){
            CharSequence cs=i.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if(cs!=null && cs.length()>0)pendingSharedText=cs.toString();
        }
    }
    void deliverTarget(){
        final String t=pendingTarget; pendingTarget="now";
        String tab="calendar".equals(t)?"calendar":("waiting".equals(t)?"waiting":"now");
        if(webView!=null) webView.postDelayed(()->{
            webView.evaluateJavascript("try{BF.tab('"+tab+"')}catch(e){}",null);
            if(pendingSharedText!=null){String shared=pendingSharedText;pendingSharedText=null;webView.evaluateJavascript("try{BF.receiveSharedText("+JSONObject.quote(shared)+")}catch(e){}",null);}
        },300);
    }
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);pendingTarget=i.getStringExtra("brainflow_target");if(pendingTarget==null)pendingTarget="now";captureIncoming(i);deliverTarget();}
    String mime(String r){if(r.endsWith(".html"))return"text/html";if(r.endsWith(".js"))return"application/javascript";if(r.endsWith(".css"))return"text/css";if(r.endsWith(".png"))return"image/png";if(r.endsWith(".svg"))return"image/svg+xml";return"application/octet-stream";}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}

    void requestNotificationsIfNeeded(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            runOnUiThread(()->requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_PERMISSION_REQUEST));
        }
    }
    void sendTestWhenAllowed(String title,String body,String target){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            pendingTestNotification=true;
            pendingTestTitle=title==null?"BrainFlow test":title;
            pendingTestBody=body==null?"Notifications are working.":body;
            pendingTestTarget=target==null?"now":target;
            requestNotificationsIfNeeded();
            return;
        }
        NotificationReceiver.showNow(this,title,body,target);
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==NOTIFICATION_PERMISSION_REQUEST){
            boolean granted=grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED;
            if(granted && pendingTestNotification){
                pendingTestNotification=false;
                NotificationReceiver.showNow(this,pendingTestTitle,pendingTestBody,pendingTestTarget);
            } else if(!granted){
                pendingTestNotification=false;
            }
            if(webView!=null){
                final boolean ok=granted;
                webView.post(()->webView.evaluateJavascript("try{BF.nativeNotificationPermissionResult("+ok+")}catch(e){}",null));
            }
        }
    }

    public class NativeBridge {
        @JavascriptInterface public void requestNotificationPermission(){requestNotificationsIfNeeded();}
        @JavascriptInterface public void scheduleReminder(String id,long when,String title,String body,String target){NotificationReceiver.schedule(MainActivity.this,id,when,title,body,target);}
        @JavascriptInterface public void cancelAllEventReminders(){NotificationReceiver.cancelEventAlarms(MainActivity.this);}
        @JavascriptInterface public void setDailyCheckIn(boolean enabled,int hour,int minute){NotificationReceiver.setDaily(MainActivity.this,enabled,hour,minute);}
        @JavascriptInterface public void setMorningSummary(boolean enabled){NotificationReceiver.setMorningSummary(MainActivity.this,enabled);}
        @JavascriptInterface public void updateDailySnapshot(int tasks,int calendar){NotificationReceiver.updateDailySnapshot(MainActivity.this,tasks,calendar);}
        @JavascriptInterface public void testNotification(String title,String body,String target){runOnUiThread(()->sendTestWhenAllowed(title,body,target));}
        @JavascriptInterface public String notificationPermission(){if(Build.VERSION.SDK_INT<33)return"granted";return checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED?"granted":"needed";}
        @JavascriptInterface public void shareText(String subject,String text){runOnUiThread(()->{try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,subject==null?"BrainFlow":subject);i.putExtra(Intent.EXTRA_TEXT,text==null?"":text);startActivity(Intent.createChooser(i,"Share with"));}catch(Exception ignored){}});}
        @JavascriptInterface public void addToCalendar(String title,String description,String location,long startMillis,long endMillis,boolean allDay){runOnUiThread(()->{try{Intent i=new Intent(Intent.ACTION_INSERT);i.setData(CalendarContract.Events.CONTENT_URI);i.putExtra(CalendarContract.Events.TITLE,title==null?"BrainFlow item":title);i.putExtra(CalendarContract.Events.DESCRIPTION,description==null?"":description);i.putExtra(CalendarContract.Events.EVENT_LOCATION,location==null?"":location);i.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME,startMillis);i.putExtra(CalendarContract.EXTRA_EVENT_END_TIME,endMillis);i.putExtra(CalendarContract.Events.ALL_DAY,allDay);startActivity(i);}catch(Exception ignored){}});}
        @JavascriptInterface public void openDialer(String phone){runOnUiThread(()->{try{startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(phone))));}catch(Exception ignored){}});}
        @JavascriptInterface public void openSms(String phone,String body){runOnUiThread(()->{try{Intent i=new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:"+Uri.encode(phone)));i.putExtra("sms_body",body==null?"":body);startActivity(i);}catch(Exception ignored){}});}
        @JavascriptInterface public void openEmail(String email,String subject,String body){runOnUiThread(()->{try{Intent i=new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:"+Uri.encode(email)));i.putExtra(Intent.EXTRA_SUBJECT,subject==null?"":subject);i.putExtra(Intent.EXTRA_TEXT,body==null?"":body);startActivity(i);}catch(Exception ignored){}});}
        @JavascriptInterface public void openMaps(String location){runOnUiThread(()->{try{Uri u=Uri.parse("geo:0,0?q="+Uri.encode(location));startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}});}
    }
}
