package com.brainflow.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.*;
import android.webkit.*;

public class MainActivity extends Activity {
    static final String HOST="appassets.androidplatform.net";
    WebView webView;
    String pendingTarget="now";

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        NotificationReceiver.ensureChannels(this);
        pendingTarget=getIntent().getStringExtra("brainflow_target");
        if(pendingTarget==null) pendingTarget="now";
        webView=new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#f3f5ff"));
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setLoadsImagesAutomatically(true);
        if(Build.VERSION.SDK_INT>=21) s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new NativeBridge(),"BrainFlowNative");
        webView.setWebChromeClient(new WebChromeClient()); webView.setWebViewClient(new Client());
        setContentView(webView); webView.loadUrl("https://"+HOST+"/index.html");
    }
    class Client extends WebViewClient {
        @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){
            if(!HOST.equals(r.getUrl().getHost())) return null;
            String p=r.getUrl().getPath(); if(p==null||p.equals("/")||p.isEmpty())p="/index.html";
            try{String rel=p.startsWith("/")?p.substring(1):p; return new WebResourceResponse(mime(rel),"utf-8",getAssets().open(rel));}
            catch(Exception e){return null;}
        }
        @Override public void onPageFinished(WebView v,String url){super.onPageFinished(v,url);deliverTarget();}
    }
    void deliverTarget(){
        final String t=pendingTarget; pendingTarget="now";
        String tab="calendar".equals(t)?"calendar":("waiting".equals(t)?"waiting":"now");
        if(webView!=null) webView.postDelayed(()->webView.evaluateJavascript("try{BF.tab('"+tab+"')}catch(e){}",null),300);
    }
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);pendingTarget=i.getStringExtra("brainflow_target");if(pendingTarget==null)pendingTarget="now";deliverTarget();}
    String mime(String r){if(r.endsWith(".html"))return"text/html";if(r.endsWith(".js"))return"application/javascript";if(r.endsWith(".css"))return"text/css";if(r.endsWith(".png"))return"image/png";if(r.endsWith(".svg"))return"image/svg+xml";return"application/octet-stream";}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}

    public class NativeBridge {
        @JavascriptInterface public void requestNotificationPermission(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)runOnUiThread(()->requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},2001));}
        @JavascriptInterface public void scheduleReminder(String id,long when,String title,String body,String target){NotificationReceiver.schedule(MainActivity.this,id,when,title,body,target);}
        @JavascriptInterface public void cancelAllEventReminders(){NotificationReceiver.cancelEventAlarms(MainActivity.this);}
        @JavascriptInterface public void setDailyCheckIn(boolean enabled,int hour,int minute){NotificationReceiver.setDaily(MainActivity.this,enabled,hour,minute);}
        @JavascriptInterface public void setMorningSummary(boolean enabled){NotificationReceiver.setMorningSummary(MainActivity.this,enabled);}
        @JavascriptInterface public void updateDailySnapshot(int tasks,int calendar){NotificationReceiver.updateDailySnapshot(MainActivity.this,tasks,calendar);}
        @JavascriptInterface public void testNotification(String title,String body,String target){NotificationReceiver.showNow(MainActivity.this,title,body,target);}
        @JavascriptInterface public String notificationPermission(){if(Build.VERSION.SDK_INT<33)return"granted";return checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED?"granted":"needed";}
    }
}
