package com.brainflow.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.provider.CalendarContract;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import org.json.JSONObject;
import android.os.*;
import android.webkit.*;
import android.view.View;
import android.content.res.Configuration;
import android.content.MutableContextWrapper;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.ClearCredentialStateRequest;
import androidx.credentials.exceptions.GetCredentialException;
import androidx.credentials.exceptions.ClearCredentialException;
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

public class MainActivity extends Activity {
    static final String HOST="appassets.androidplatform.net";
    static final int NOTIFICATION_PERMISSION_REQUEST=2001;
    static final String WEB_CLIENT_ID="1095525758107-6ibci50b9otvup78u8otfej2dnmis26u.apps.googleusercontent.com";
    static final String AUTH_PREFS="brainflow_auth";
    CredentialManager credentialManager;
    WebView webView;
    String pendingTarget="now";
    String pendingSharedText=null;
    String pendingCalendarSuggestionJson=null;
    boolean pendingTestNotification=false;
    String pendingTestTitle="BrainFlow test";
    String pendingTestBody="Notifications are working.";
    String pendingTestTarget="now";

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        if(Build.VERSION.SDK_INT>=21){
            getWindow().setStatusBarColor(Color.parseColor("#07101f"));
            getWindow().setNavigationBarColor(Color.parseColor("#f3f5ff"));
            if(Build.VERSION.SDK_INT>=23){
                getWindow().getDecorView().setSystemUiVisibility(getWindow().getDecorView().getSystemUiVisibility() & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            }
        }
        NotificationReceiver.ensureChannels(this);
        credentialManager=CredentialManager.create(this);
        pendingTarget=getIntent().getStringExtra("brainflow_target");
        if(pendingTarget==null) pendingTarget="now";
        captureIncoming(getIntent());
        webView=new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#f3f5ff"));
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setLoadsImagesAutomatically(true);
        if(Build.VERSION.SDK_INT>=21) s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new NativeBridge(),"BrainFlowNative");
        webView.setWebChromeClient(new WebChromeClient()); webView.setWebViewClient(new Client());
        setContentView(webView); webView.loadUrl("https://"+HOST+"/index.html");
    }
    @Override public void onConfigurationChanged(Configuration newConfig){
        super.onConfigurationChanged(newConfig);
        if(webView!=null) webView.post(()->webView.evaluateJavascript("try{BF.nativeSystemThemeChanged()}catch(e){}",null));
    }
    boolean isSystemDark(){return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;}
    class Client extends WebViewClient {
        @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){
            if(!HOST.equals(r.getUrl().getHost())) return null;
            String p=r.getUrl().getPath(); if(p==null||p.equals("/")||p.isEmpty())p="/index.html";
            try{String rel=p.startsWith("/")?p.substring(1):p; return new WebResourceResponse(mime(rel),"utf-8",getAssets().open(rel));}
            catch(Exception e){return null;}
        }
        @Override public void onPageFinished(WebView v,String url){super.onPageFinished(v,url);deliverTarget();}
    }
    void captureIncoming(Intent i){
        if(i==null)return;
        String type=i.getType()==null?"":i.getType().toLowerCase(Locale.US);
        String action=i.getAction()==null?"":i.getAction();
        Uri incomingData=i.getData();
        boolean calendarInsert=Intent.ACTION_INSERT.equals(action)||Intent.ACTION_INSERT_OR_EDIT.equals(action);
        boolean calendarUri=incomingData!=null&&"content".equalsIgnoreCase(incomingData.getScheme())&&"com.android.calendar".equalsIgnoreCase(incomingData.getHost());
        boolean calendarMime=type.contains("calendar")||type.contains("ics")||type.contains("vnd.android.cursor.dir/event")||type.contains("vnd.android.cursor.item/event");
        if(calendarInsert&&(calendarUri||calendarMime)){
            String parsed=parseCalendarInsertSuggestion(i);
            if(parsed!=null)pendingCalendarSuggestionJson=parsed;
            pendingTarget="calendar";
            return;
        }
        boolean calendarType=type.contains("calendar")||type.contains("ics");
        if(calendarType){
            Uri u=null;
            if(Intent.ACTION_SEND.equals(i.getAction())){
                if(Build.VERSION.SDK_INT>=33)u=i.getParcelableExtra(Intent.EXTRA_STREAM,Uri.class);
                else u=(Uri)i.getParcelableExtra(Intent.EXTRA_STREAM);
            } else if(Intent.ACTION_VIEW.equals(i.getAction())) u=i.getData();
            String raw=readUriText(u);
            if((raw==null||raw.trim().isEmpty()) && Intent.ACTION_SEND.equals(i.getAction())){
                CharSequence cs=i.getCharSequenceExtra(Intent.EXTRA_TEXT); if(cs!=null)raw=cs.toString();
            }
            String parsed=parseCalendarSuggestion(raw);
            if(parsed!=null)pendingCalendarSuggestionJson=parsed;
            return;
        }
        if(Intent.ACTION_SEND.equals(i.getAction()) && type.startsWith("text/")){
            CharSequence cs=i.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if(cs!=null && cs.length()>0)pendingSharedText=cs.toString();
        }
    }
    String readUriText(Uri u){
        if(u==null)return null;
        try(InputStream in=getContentResolver().openInputStream(u); ByteArrayOutputStream out=new ByteArrayOutputStream()){
            if(in==null)return null; byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0)out.write(buf,0,n); return out.toString("UTF-8");
        }catch(Exception e){return null;}
    }
    static String icsUnescape(String v){if(v==null)return"";return v.replace("\\n","\n").replace("\\N","\n").replace("\\,",",").replace("\\;",";").replace("\\\\","\\");}
    static String icsValue(String raw,String name){
        if(raw==null)return null; String unfolded=raw.replaceAll("\r?\n[ \t]","");
        for(String line:unfolded.split("\r?\n")){int c=line.indexOf(':');if(c<0)continue;String left=line.substring(0,c);String base=left.split(";",2)[0];if(base.equalsIgnoreCase(name))return icsUnescape(line.substring(c+1).trim());}
        return null;
    }
    static String icsLeft(String raw,String name){
        if(raw==null)return null; String unfolded=raw.replaceAll("\r?\n[ \t]","");
        for(String line:unfolded.split("\r?\n")){int c=line.indexOf(':');if(c<0)continue;String left=line.substring(0,c);String base=left.split(";",2)[0];if(base.equalsIgnoreCase(name))return left;}return null;
    }
    static long parseIcsDate(String value,String left){
        if(value==null||value.isEmpty())return 0L; try{
            boolean dateOnly=value.matches("\\d{8}"); boolean utc=value.endsWith("Z"); String pattern=dateOnly?"yyyyMMdd":(value.length()>=15?"yyyyMMdd'T'HHmmss":"yyyyMMdd'T'HHmm");
            String val=utc?value.substring(0,value.length()-1):value; SimpleDateFormat f=new SimpleDateFormat(pattern,Locale.US); f.setLenient(false);
            TimeZone tz=TimeZone.getDefault(); if(utc)tz=TimeZone.getTimeZone("UTC"); else if(left!=null&&left.toUpperCase(Locale.US).contains("TZID=")){String id=left.substring(left.toUpperCase(Locale.US).indexOf("TZID=")+5);int semi=id.indexOf(';');if(semi>=0)id=id.substring(0,semi);tz=TimeZone.getTimeZone(id);}
            f.setTimeZone(tz); Date d=f.parse(val); return d==null?0L:d.getTime();
        }catch(Exception e){return 0L;}
    }
    static String organizerName(String raw){String o=icsValue(raw,"ORGANIZER");String left=icsLeft(raw,"ORGANIZER");if(left!=null){String up=left.toUpperCase(Locale.US);int i=up.indexOf("CN=");if(i>=0){String x=left.substring(i+3);int semi=x.indexOf(';');if(semi>=0)x=x.substring(0,semi);x=x.replace("\"","").trim();if(!x.isEmpty())return x;}}if(o!=null&&o.toLowerCase(Locale.US).startsWith("mailto:"))return o.substring(7);return o==null?"":o;}
    static String parseCalendarSuggestion(String raw){
        if(raw==null||!raw.toUpperCase(Locale.US).contains("BEGIN:VEVENT"))return null; try{String title=icsValue(raw,"SUMMARY");if(title==null||title.trim().isEmpty())title="Suggested event";String ds=icsValue(raw,"DTSTART"),de=icsValue(raw,"DTEND");String ls=icsLeft(raw,"DTSTART"),le=icsLeft(raw,"DTEND");long start=parseIcsDate(ds,ls),end=parseIcsDate(de,le);if(start==0L)return null;if(end==0L)end=start+30*60*1000L;boolean allDay=(ls!=null&&ls.toUpperCase(Locale.US).contains("VALUE=DATE"))||(ds!=null&&ds.matches("\\d{8}"));JSONObject j=new JSONObject();j.put("title",title);j.put("description",icsValue(raw,"DESCRIPTION"));j.put("location",icsValue(raw,"LOCATION"));j.put("organizer",organizerName(raw));j.put("startMillis",start);j.put("endMillis",end);j.put("allDay",allDay);j.put("source","calendar invite");return j.toString();}catch(Exception e){return null;}
    }
    static String parseCalendarInsertSuggestion(Intent i){
        try{
            String title=i.getStringExtra(CalendarContract.Events.TITLE);
            String description=i.getStringExtra(CalendarContract.Events.DESCRIPTION);
            String location=i.getStringExtra(CalendarContract.Events.EVENT_LOCATION);
            long start=i.getLongExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME,0L);
            long end=i.getLongExtra(CalendarContract.EXTRA_EVENT_END_TIME,0L);
            boolean allDay=i.getBooleanExtra(CalendarContract.Events.ALL_DAY,false);
            if(title==null||title.trim().isEmpty())title="Suggested event";
            if(start<=0L)return null;
            if(end<=start)end=start+(allDay?24L*60L*60L*1000L:30L*60L*1000L);
            JSONObject j=new JSONObject();
            j.put("title",title);j.put("description",description==null?"":description);j.put("location",location==null?"":location);j.put("organizer","");
            j.put("startMillis",start);j.put("endMillis",end);j.put("allDay",allDay);j.put("source","Android calendar suggestion");
            return j.toString();
        }catch(Exception e){return null;}
    }
    void deliverTarget(){
        final String t=pendingTarget; pendingTarget="now";
        String tab="calendar".equals(t)?"calendar":("waiting".equals(t)?"waiting":("dump".equals(t)?"dump":("task".equals(t)?"tasks":"now")));
        if(webView!=null) webView.postDelayed(()->{
            webView.evaluateJavascript("try{BF.tab('"+tab+"');"+("task".equals(t)?"BF.newTask();":("event".equals(t)?"BF.newAppt();":""))+"}catch(e){}",null);
            if(pendingCalendarSuggestionJson!=null){String sug=pendingCalendarSuggestionJson;pendingCalendarSuggestionJson=null;webView.evaluateJavascript("try{BF.receiveCalendarSuggestion("+JSONObject.quote(sug)+")}catch(e){}",null);}
            else if(pendingSharedText!=null){String shared=pendingSharedText;pendingSharedText=null;webView.evaluateJavascript("try{BF.receiveSharedText("+JSONObject.quote(shared)+")}catch(e){}",null);}
        },300);
    }
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);pendingTarget=i.getStringExtra("brainflow_target");if(pendingTarget==null)pendingTarget="now";captureIncoming(i);deliverTarget();}
    String mime(String r){if(r.endsWith(".html"))return"text/html";if(r.endsWith(".js"))return"application/javascript";if(r.endsWith(".css"))return"text/css";if(r.endsWith(".png"))return"image/png";if(r.endsWith(".svg"))return"image/svg+xml";return"application/octet-stream";}
    @Override public void onBackPressed(){
        if(webView==null){super.onBackPressed();return;}
        webView.evaluateJavascript("(function(){try{return !!BF.nativeBack()}catch(e){return false}})()", value->{
            if(!"true".equals(value)) MainActivity.super.onBackPressed();
        });
    }

    void requestNotificationsIfNeeded(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            runOnUiThread(()->requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_PERMISSION_REQUEST));
        }
    }
    void sendTestWhenAllowed(String title,String body,String target){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            pendingTestNotification=true;
            pendingTestTitle=title==null?"BrainFlow test":title;
            pendingTestBody=body==null?"Notifications are working.":body;
            pendingTestTarget=target==null?"now":target;
            requestNotificationsIfNeeded();
            return;
        }
        NotificationReceiver.showNow(this,title,body,target);
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==NOTIFICATION_PERMISSION_REQUEST){
            boolean granted=grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED;
            if(granted && pendingTestNotification){
                pendingTestNotification=false;
                NotificationReceiver.showNow(this,pendingTestTitle,pendingTestBody,pendingTestTarget);
            } else if(!granted){
                pendingTestNotification=false;
            }
            if(webView!=null){
                final boolean ok=granted;
                webView.post(()->webView.evaluateJavascript("try{BF.nativeNotificationPermissionResult("+ok+")}catch(e){}",null));
            }
        }
    }

    static String icsEscape(String s){if(s==null)return"";return s.replace("\\","\\\\").replace(";","\\;").replace(",","\\,").replace("\r\n","\\n").replace("\n","\\n").replace("\r","\\n");}
    static String icsUtc(long ms){SimpleDateFormat f=new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(ms));}

    void applySystemBars(boolean dark){runOnUiThread(()->{try{getWindow().setStatusBarColor(dark?Color.rgb(12,17,32):Color.rgb(245,246,251));getWindow().setNavigationBarColor(dark?Color.rgb(12,17,32):Color.rgb(245,246,251));int flags=getWindow().getDecorView().getSystemUiVisibility();if(Build.VERSION.SDK_INT>=23){if(!dark)flags|=android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;else flags&=~android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;}if(Build.VERSION.SDK_INT>=26){if(!dark)flags|=android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;else flags&=~android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;}getWindow().getDecorView().setSystemUiVisibility(flags);}catch(Exception ignored){}});}

    String authStateJson(){
        try{
            SharedPreferences p=getSharedPreferences(AUTH_PREFS,MODE_PRIVATE);
            JSONObject j=new JSONObject();
            boolean signed=p.getBoolean("signedIn",false);
            j.put("signedIn",signed);
            if(signed){
                j.put("provider","google");
                j.put("name",p.getString("name",""));
                j.put("email",p.getString("email",""));
                j.put("photo",p.getString("photo",""));
            }
            return j.toString();
        }catch(Exception e){return "{\"signedIn\":false}";}
    }
    void sendAuthCallback(String fn,String json){
        if(webView==null)return;
        String safe=json==null?"{}":json;
        webView.post(()->webView.evaluateJavascript("try{BF."+fn+"("+JSONObject.quote(safe)+")}catch(e){}",null));
    }
    void saveGoogleAccount(GoogleIdTokenCredential g){
        String name=g.getDisplayName(); if(name==null)name="";
        String email=g.getId(); if(email==null)email="";
        String photo=g.getProfilePictureUri()==null?"":g.getProfilePictureUri().toString();
        getSharedPreferences(AUTH_PREFS,MODE_PRIVATE).edit()
            .putBoolean("signedIn",true).putString("name",name).putString("email",email).putString("photo",photo).apply();
    }
    void startGoogleLogin(){
        try{
            GetSignInWithGoogleOption googleOption=new GetSignInWithGoogleOption.Builder(WEB_CLIENT_ID).build();
            GetCredentialRequest request=new GetCredentialRequest.Builder().addCredentialOption(googleOption).build();
            credentialManager.getCredentialAsync(
                new MutableContextWrapper(MainActivity.this), request, null, getMainExecutor(),
                new CredentialManagerCallback<GetCredentialResponse,GetCredentialException>(){
                    @Override public void onResult(GetCredentialResponse result){
                        try{
                            Credential c=result.getCredential();
                            if(c instanceof CustomCredential){
                                CustomCredential custom=(CustomCredential)c;
                                if(GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(custom.getType())){
                                    GoogleIdTokenCredential g=GoogleIdTokenCredential.createFrom(custom.getData());
                                    saveGoogleAccount(g);
                                    sendAuthCallback("nativeGoogleLoginResult",authStateJson());
                                    return;
                                }
                            }
                            sendAuthCallback("nativeGoogleLoginError","{\"message\":\"Google returned an unsupported sign-in response.\"}");
                        }catch(Exception e){
                            sendAuthCallback("nativeGoogleLoginError","{\"message\":\"Google sign-in could not be completed.\"}");
                        }
                    }
                    @Override public void onError(GetCredentialException e){
                        String n=e.getClass().getSimpleName();
                        String msg=n!=null&&n.toLowerCase(Locale.US).contains("cancel")?"Sign-in cancelled.":"Google sign-in did not complete. Try again.";
                        try{JSONObject j=new JSONObject();j.put("message",msg);sendAuthCallback("nativeGoogleLoginError",j.toString());}
                        catch(Exception ignored){sendAuthCallback("nativeGoogleLoginError","{\"message\":\"Google sign-in did not complete.\"}");}
                    }
                });
        }catch(Exception e){
            sendAuthCallback("nativeGoogleLoginError","{\"message\":\"Google sign-in is unavailable on this device.\"}");
        }
    }
    void startGoogleLogout(){
        getSharedPreferences(AUTH_PREFS,MODE_PRIVATE).edit().clear().apply();
        try{
            ClearCredentialStateRequest request=new ClearCredentialStateRequest(ClearCredentialStateRequest.TYPE_CLEAR_CREDENTIAL_STATE);
            credentialManager.clearCredentialStateAsync(request,null,getMainExecutor(),new CredentialManagerCallback<Void,ClearCredentialException>(){
                @Override public void onResult(Void result){sendAuthCallback("nativeGoogleLogoutResult",authStateJson());}
                @Override public void onError(ClearCredentialException e){sendAuthCallback("nativeGoogleLogoutResult",authStateJson());}
            });
        }catch(Exception e){sendAuthCallback("nativeGoogleLogoutResult",authStateJson());}
    }

    public class NativeBridge {
        @JavascriptInterface public void requestNotificationPermission(){requestNotificationsIfNeeded();}
        @JavascriptInterface public String systemDark(){return isSystemDark()?"true":"false";}
        @JavascriptInterface public String googleLogin(){runOnUiThread(()->startGoogleLogin());return "started";}
        @JavascriptInterface public String googleLogout(){runOnUiThread(()->startGoogleLogout());return "started";}
        @JavascriptInterface public String getAuthState(){return authStateJson();}
        @JavascriptInterface public void updateWidgetSnapshot(String json){try{getSharedPreferences(BrainFlowWidgetProvider.PREFS,0).edit().putString("snapshot",json==null?"{}":json).apply();BrainFlowWidgetProvider.updateAll(MainActivity.this);}catch(Exception ignored){}}
        @JavascriptInterface public void setSystemBarDark(boolean dark){applySystemBars(dark);}
        @JavascriptInterface public void scheduleReminder(String id,long when,String title,String body,String target){NotificationReceiver.schedule(MainActivity.this,id,when,title,body,target);}
        @JavascriptInterface public void cancelAllEventReminders(){NotificationReceiver.cancelEventAlarms(MainActivity.this);}
        @JavascriptInterface public void setDailyCheckIn(boolean enabled,int hour,int minute){NotificationReceiver.setDaily(MainActivity.this,enabled,hour,minute);}
        @JavascriptInterface public void setMorningSummary(boolean enabled){NotificationReceiver.setMorningSummary(MainActivity.this,enabled);}
        @JavascriptInterface public void updateDailySnapshot(int tasks,int calendar){NotificationReceiver.updateDailySnapshot(MainActivity.this,tasks,calendar);}
        @JavascriptInterface public void testNotification(String title,String body,String target){runOnUiThread(()->sendTestWhenAllowed(title,body,target));}
        @JavascriptInterface public String notificationPermission(){if(Build.VERSION.SDK_INT<33)return"granted";return checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED?"granted":"needed";}
        @JavascriptInterface public void shareText(String subject,String text){runOnUiThread(()->{try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,subject==null?"BrainFlow":subject);i.putExtra(Intent.EXTRA_TEXT,text==null?"":text);startActivity(Intent.createChooser(i,"Share with"));}catch(Exception ignored){}});}
        @JavascriptInterface public void shareCalendarInvite(String title,String description,String location,long startMillis,long endMillis,boolean allDay){runOnUiThread(()->{try{
            String safe=(title==null||title.trim().isEmpty())?"BrainFlow Event":title.trim();
            String uid=System.currentTimeMillis()+"@brainflow";
            String dtstamp=icsUtc(System.currentTimeMillis());
            StringBuilder ics=new StringBuilder();
            ics.append("BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//BrainFlow//Calendar Invite//EN\r\nCALSCALE:GREGORIAN\r\nMETHOD:PUBLISH\r\nBEGIN:VEVENT\r\n");
            ics.append("UID:").append(icsEscape(uid)).append("\r\n");
            ics.append("DTSTAMP:").append(dtstamp).append("\r\n");
            if(allDay){
                SimpleDateFormat d=new SimpleDateFormat("yyyyMMdd",Locale.US);
                d.setTimeZone(TimeZone.getDefault());
                ics.append("DTSTART;VALUE=DATE:").append(d.format(new Date(startMillis))).append("\r\n");
                ics.append("DTEND;VALUE=DATE:").append(d.format(new Date(endMillis))).append("\r\n");
            }else{
                ics.append("DTSTART:").append(icsUtc(startMillis)).append("\r\n");
                ics.append("DTEND:").append(icsUtc(endMillis)).append("\r\n");
            }
            ics.append("SUMMARY:").append(icsEscape(safe)).append("\r\n");
            if(description!=null&&!description.isEmpty())ics.append("DESCRIPTION:").append(icsEscape(description)).append("\r\n");
            if(location!=null&&!location.isEmpty())ics.append("LOCATION:").append(icsEscape(location)).append("\r\n");
            ics.append("END:VEVENT\r\nEND:VCALENDAR\r\n");
            File dir=new File(getCacheDir(),"ics"); if(!dir.exists())dir.mkdirs();
            String fn="BrainFlow-"+System.currentTimeMillis()+".ics"; File f=new File(dir,fn);
            try(FileOutputStream out=new FileOutputStream(f)){out.write(ics.toString().getBytes(StandardCharsets.UTF_8));}
            Uri uri=Uri.parse("content://"+getPackageName()+".icsprovider/"+fn);
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/calendar");
            i.putExtra(Intent.EXTRA_SUBJECT,safe); i.putExtra(Intent.EXTRA_TEXT,"Calendar invite: "+safe); i.putExtra(Intent.EXTRA_STREAM,uri);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i,"Share calendar invite"));
        }catch(Exception ignored){}});}
        @JavascriptInterface public void addToCalendar(String title,String description,String location,long startMillis,long endMillis,boolean allDay){runOnUiThread(()->{try{Intent i=new Intent(Intent.ACTION_INSERT);i.setData(CalendarContract.Events.CONTENT_URI);i.putExtra(CalendarContract.Events.TITLE,title==null?"BrainFlow item":title);i.putExtra(CalendarContract.Events.DESCRIPTION,description==null?"":description);i.putExtra(CalendarContract.Events.EVENT_LOCATION,location==null?"":location);i.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME,startMillis);i.putExtra(CalendarContract.EXTRA_EVENT_END_TIME,endMillis);i.putExtra(CalendarContract.Events.ALL_DAY,allDay);startActivity(i);}catch(Exception ignored){}});}
        @JavascriptInterface public void openDialer(String phone){runOnUiThread(()->{try{startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(phone))));}catch(Exception ignored){}});}
        @JavascriptInterface public void openSms(String phone,String body){runOnUiThread(()->{try{Intent i=new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:"+Uri.encode(phone)));i.putExtra("sms_body",body==null?"":body);startActivity(i);}catch(Exception ignored){}});}
        @JavascriptInterface public void openEmail(String email,String subject,String body){runOnUiThread(()->{try{Intent i=new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:"+Uri.encode(email)));i.putExtra(Intent.EXTRA_SUBJECT,subject==null?"":subject);i.putExtra(Intent.EXTRA_TEXT,body==null?"":body);startActivity(i);}catch(Exception ignored){}});}
        @JavascriptInterface public void openMaps(String location){runOnUiThread(()->{try{Uri u=Uri.parse("geo:0,0?q="+Uri.encode(location));startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}});}
    }
}
