package com.brainflow.app;
public class BrainWidget extends BrainFlowWidgetProvider {}
