package com.brainflow.app;

import android.app.*;
import android.content.*;
import android.os.Build;
import java.util.*;

public class NotificationReceiver extends BroadcastReceiver {
    static final String CHANNEL_SCHEDULE="brainflow_schedule";
    static final String CHANNEL_DAILY="brainflow_daily";
    static final int DAILY_CODE=741001, MORNING_CODE=741002, TEST_CODE=741003;
    static final String PREF="brainflow_native", EVENT_PREFIX="event_record_";

    public static void ensureChannels(Context c){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager n=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel schedule=new NotificationChannel(CHANNEL_SCHEDULE,"Calendar & follow-up reminders",NotificationManager.IMPORTANCE_HIGH);
            schedule.setDescription("BrainFlow event and follow-up reminders");
            NotificationChannel daily=new NotificationChannel(CHANNEL_DAILY,"BrainFlow check-ins",NotificationManager.IMPORTANCE_DEFAULT);
            daily.setDescription("Daily check-in and morning summary reminders");
            n.createNotificationChannel(schedule); n.createNotificationChannel(daily);
        }
    }
    static int code(String id){return 10000+Math.abs(id.hashCode()%600000);}
    static PendingIntent broadcast(Context c,int req,Intent i){return PendingIntent.getBroadcast(c,req,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    static String pack(long when,String title,String body,String target){return when+"\u001f"+safe(title)+"\u001f"+safe(body)+"\u001f"+safe(target);}
    static String safe(String x){return x==null?"":x.replace("\u001f"," ");}

    public static void schedule(Context c,String id,long when,String title,String body,String target){
        if(when<=System.currentTimeMillis())return;
        int req=code(id); scheduleAlarm(c,req,when,title,body,target);
        SharedPreferences p=c.getSharedPreferences(PREF,0);
        Set<String> ids=new HashSet<>(p.getStringSet("event_codes",Collections.emptySet())); ids.add(String.valueOf(req));
        p.edit().putStringSet("event_codes",ids).putString(EVENT_PREFIX+req,pack(when,title,body,target)).apply();
    }
    static void scheduleAlarm(Context c,int req,long when,String title,String body,String target){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent i=new Intent(c,NotificationReceiver.class).putExtra("title",title).putExtra("body",body).putExtra("target",target).putExtra("nid",req).putExtra("channel",CHANNEL_SCHEDULE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,broadcast(c,req,i));
    }
    public static void cancelEventAlarms(Context c){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); SharedPreferences p=c.getSharedPreferences(PREF,0);
        SharedPreferences.Editor e=p.edit();
        for(String x:p.getStringSet("event_codes",Collections.emptySet()))try{int req=Integer.parseInt(x);am.cancel(broadcast(c,req,new Intent(c,NotificationReceiver.class)));e.remove(EVENT_PREFIX+req);}catch(Exception ignored){}
        e.remove("event_codes").apply();
    }
    public static void reschedulePersistedEvents(Context c){
        SharedPreferences p=c.getSharedPreferences(PREF,0); long now=System.currentTimeMillis(); Set<String> keep=new HashSet<>(); SharedPreferences.Editor e=p.edit();
        for(String x:p.getStringSet("event_codes",Collections.emptySet()))try{
            int req=Integer.parseInt(x); String raw=p.getString(EVENT_PREFIX+req,""); String[] a=raw.split("\u001f",-1); if(a.length<4){e.remove(EVENT_PREFIX+req);continue;}
            long when=Long.parseLong(a[0]); if(when<=now){e.remove(EVENT_PREFIX+req);continue;}
            scheduleAlarm(c,req,when,a[1],a[2],a[3]); keep.add(x);
        }catch(Exception ignored){}
        e.putStringSet("event_codes",keep).apply();
    }
    public static void updateDailySnapshot(Context c,int tasks,int calendar){c.getSharedPreferences(PREF,0).edit().putInt("today_tasks",Math.max(0,tasks)).putInt("today_calendar",Math.max(0,calendar)).apply();}
    public static void setDaily(Context c,boolean enabled,int hour,int minute){
        SharedPreferences p=c.getSharedPreferences(PREF,0);p.edit().putBoolean("daily",enabled).putInt("hour",hour).putInt("minute",minute).apply();
        scheduleRepeating(c,DAILY_CODE,enabled,hour,minute,"daily");
    }
    public static void setMorningSummary(Context c,boolean enabled){
        c.getSharedPreferences(PREF,0).edit().putBoolean("morning",enabled).apply();
        scheduleRepeating(c,MORNING_CODE,enabled,7,30,"morning");
    }
    static void scheduleRepeating(Context c,int code,boolean enabled,int hour,int minute,String kind){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent i=new Intent(c,NotificationReceiver.class).putExtra(kind,true).putExtra("nid",code).putExtra("target","now").putExtra("channel",CHANNEL_DAILY);
        PendingIntent pi=broadcast(c,code,i);am.cancel(pi);if(!enabled)return;
        Calendar cal=Calendar.getInstance();cal.set(Calendar.HOUR_OF_DAY,hour);cal.set(Calendar.MINUTE,minute);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);if(cal.getTimeInMillis()<=System.currentTimeMillis())cal.add(Calendar.DAY_OF_YEAR,1);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);
    }
    public static void showNow(Context c,String title,String body,String target){
        ensureChannels(c); post(c,TEST_CODE,title,body,target,CHANNEL_SCHEDULE);
    }
    static void post(Context c,int nid,String title,String body,String target,String channel){
        Intent open=new Intent(c,MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("brainflow_target",target==null?"now":target);
        PendingIntent pi=PendingIntent.getActivity(c,nid,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,channel):new Notification.Builder(c);
        b.setSmallIcon(com.brainflow.app.R.drawable.ic_notification).setContentTitle(title==null?"BrainFlow":title).setContentText(body==null?"Upcoming schedule":body).setAutoCancel(true).setContentIntent(pi).setPriority(Notification.PRIORITY_HIGH);
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(nid,b.build());
    }
    @Override public void onReceive(Context c,Intent i){
        ensureChannels(c); boolean daily=i.getBooleanExtra("daily",false),morning=i.getBooleanExtra("morning",false);
        String title=i.getStringExtra("title"),body=i.getStringExtra("body"),target=i.getStringExtra("target"),channel=i.getStringExtra("channel");
        if(daily||morning){SharedPreferences p=c.getSharedPreferences(PREF,0);int tasks=p.getInt("today_tasks",0),cal=p.getInt("today_calendar",0);title=morning?"Your BrainFlow morning":"Check BrainFlow";body=tasks+" task"+(tasks==1?"":"s")+" and "+cal+" calendar item"+(cal==1?"":"s")+" coming up.";target="now";channel=CHANNEL_DAILY;}
        if(channel==null)channel=CHANNEL_SCHEDULE; post(c,i.getIntExtra("nid",7),title,body,target,channel);
    }
}
