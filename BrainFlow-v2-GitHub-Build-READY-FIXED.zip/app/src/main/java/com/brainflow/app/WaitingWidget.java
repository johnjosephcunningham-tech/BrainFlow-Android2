package com.brainflow.app;
public class WaitingWidget extends BrainFlowWidgetProvider {}
