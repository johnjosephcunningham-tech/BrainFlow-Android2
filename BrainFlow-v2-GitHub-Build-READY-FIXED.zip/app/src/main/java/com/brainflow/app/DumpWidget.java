package com.brainflow.app;
public class DumpWidget extends BrainFlowWidgetProvider {}
