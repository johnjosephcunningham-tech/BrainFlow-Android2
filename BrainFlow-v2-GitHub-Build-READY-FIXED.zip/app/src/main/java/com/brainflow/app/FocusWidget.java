package com.brainflow.app;
public class FocusWidget extends BrainFlowWidgetProvider {}
