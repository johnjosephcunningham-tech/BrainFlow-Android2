# BrainFlow Android

Native Android WebView wrapper for the bundled offline BrainFlow web app.

The GitHub Actions workflow builds a normal Android APK using Gradle and the official Android toolchain.

Output artifact: `BrainFlow-v1.0.6-apk` containing `app-debug.apk`.
