package com.brainflow.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * BrainFlow — Your External Brain
 *
 * Minimal, dependency-free Android wrapper that serves the bundled BrainFlow
 * PWA (in /assets) straight from the APK, so the whole app runs 100% offline
 * with no server, no account, and no internet. Web Storage / IndexedDB are
 * enabled so tasks persist across app restarts and phone reboots.
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#0e1114"));

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadsImagesAutomatically(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }

        webView.setWebChromeClient(new MyChromeClient());
        webView.setWebViewClient(new MyClient());

        setContentView(webView);
        webView.loadUrl("https://" + HOST + "/index.html");
    }

    /** Serves every request from the bundled assets — no network is used. */
    private final class MyClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            if (!HOST.equals(request.getUrl().getHost())) {
                return null;
            }
            String path = request.getUrl().getPath();
            if (path == null || path.isEmpty() || path.equals("/")) {
                path = "/index.html";
            }
            try {
                String rel = path.startsWith("/") ? path.substring(1) : path;
                InputStream is = getAssets().open(rel);
                return new WebResourceResponse(guessMime(rel), "utf-8", is);
            } catch (Exception e) {
                // SPA fallback: unknown page → index.html
                if (!path.contains(".")) {
                    try {
                        InputStream is = getAssets().open("index.html");
                        return new WebResourceResponse("text/html", "utf-8", is);
                    } catch (Exception ignored) { /* fall through */ }
                }
                Map<String, String> headers = new HashMap<>();
                ByteArrayInputStream body = new ByteArrayInputStream("Not Found".getBytes());
                try {
                    return new WebResourceResponse(
                            "text/plain", "utf-8", 404, "Not Found", headers, body);
                } catch (Exception e2) {
                    return null;
                }
            }
        }
    }

    private final class MyChromeClient extends WebChromeClient {
        @Override
        public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
            new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setPositiveButton("OK", (d, w) -> result.confirm())
                    .setCancelable(false)
                    .show();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
            new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setPositiveButton("OK", (d, w) -> result.confirm())
                    .setNegativeButton("Cancel", (d, w) -> result.cancel())
                    .setCancelable(false)
                    .show();
            return true;
        }

        @Override
        public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
            return super.onJsPrompt(view, url, message, defaultValue, result);
        }
    }

    private String guessMime(String rel) {
        if (rel.endsWith(".html") || rel.endsWith(".htm")) return "text/html";
        if (rel.endsWith(".js")) return "application/javascript";
        if (rel.endsWith(".css")) return "text/css";
        if (rel.endsWith(".json")) return "application/json";
        if (rel.endsWith(".manifest") || rel.endsWith(".webmanifest")) return "application/manifest+json";
        if (rel.endsWith(".png")) return "image/png";
        if (rel.endsWith(".jpg") || rel.endsWith(".jpeg")) return "image/jpeg";
        if (rel.endsWith(".svg")) return "image/svg+xml";
        if (rel.endsWith(".webp")) return "image/webp";
        if (rel.endsWith(".gif")) return "image/gif";
        if (rel.endsWith(".ico")) return "image/x-icon";
        if (rel.endsWith(".woff")) return "font/woff";
        if (rel.endsWith(".woff2")) return "font/woff2";
        if (rel.endsWith(".ttf")) return "font/ttf";
        if (rel.endsWith(".txt")) return "text/plain";
        return "application/octet-stream";
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
